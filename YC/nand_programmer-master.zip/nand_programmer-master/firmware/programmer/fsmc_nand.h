/*  Copyright (C) 2020 NANDO authors
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License version 3.
 */

#ifndef _FSMC_NAND_H_
#define _FSMC_NAND_H_

#include "flash_hal.h"

extern flash_hal_t hal_fsmc;

#endif /* _FSMC_NAND_H_ */
