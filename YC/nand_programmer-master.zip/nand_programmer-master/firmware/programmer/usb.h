/*  Copyright (C) 2020 NANDO authors
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License version 3.
 */
 
#ifndef _USB_H_
#define _USB_H_

void usb_init();

#endif
