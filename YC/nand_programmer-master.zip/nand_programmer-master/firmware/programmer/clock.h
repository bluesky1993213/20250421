/*  Copyright (C) 2020 NANDO authors
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License version 3.
 */
 
#ifndef _CLOCK_H_
#define _CLOCK_H_

#include <stdbool.h>

bool is_external_clock_avail();

#endif
