/*  Copyright (C) 2020 NANDO authors
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License version 3.
 */

#ifndef _VERSION_H_
#define _VERSION_H_

#define SW_VERSION_MAJOR 3
#define SW_VERSION_MINOR 5
#define SW_VERSION_BUILD 0

#endif
