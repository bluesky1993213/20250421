/*  Copyright (C) 2020 NANDO authors
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License version 3.
 */

#ifndef ERR_H
#define ERR_H

const char *errCode2str(long int code);

#endif // ERR_H
