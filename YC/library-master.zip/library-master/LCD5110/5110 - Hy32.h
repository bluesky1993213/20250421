#define RESET_PIN 		GPIO_Pin_3
#define CE_PIN			GPIO_Pin_4
#define DC_PIN			GPIO_Pin_5
#define MISO_PIN		GPIO_Pin_6
#define CLK_PIN			GPIO_Pin_7
#define LED_PIN			GPIO_Pin_8

#define GPIO_CLK	 	RCC_AHB1Periph_GPIOB
#define GPIO_NAME		GPIOB
