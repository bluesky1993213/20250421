/*
 * @Author: Lukasz
 * @Date:   20-11-2018
 * @Last Modified by:   Lukasz
 * @Last Modified time: 20-11-2018
 */
#include "hdlc/random_frame_factory.h"

namespace hdlc
{
std::default_random_engine RandomFrameFactory::m_generator;
}
